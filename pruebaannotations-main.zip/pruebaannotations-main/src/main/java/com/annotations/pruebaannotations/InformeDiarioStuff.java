package com.annotations.pruebaannotations;

public class InformeDiarioStuff implements CrearDocumentos {

    @Override
    public String getDocumento() {
        return "Documento estandar del EmpleadoSTUFF";
    }


    
}
    

