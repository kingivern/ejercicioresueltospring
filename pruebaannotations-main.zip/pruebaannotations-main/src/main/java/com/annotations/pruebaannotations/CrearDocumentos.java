package com.annotations.pruebaannotations;

import org.springframework.stereotype.Component;

@Component
public interface CrearDocumentos {

    public String getDocumento();

}
