package com.annotations.pruebaannotations;

public interface Empleados {
    public String getResponsabilidades();

    //public String getDocumento();

    public String getDocumento();
    
}
